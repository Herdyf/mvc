<?php
defined('BASEPATH') or exit('No direct script access allowed');

class auth extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->library('form_validation');
        $this->load->library('recaptcha');
        $this->load->helper('captcha');
        $this->load->helper('string');
        
    }

    public function index()
    {
        $this->form_validation->set_rules('email', 'Email', 'required|trim|valid_email');
        $this->form_validation->set_rules('password', 'Password', 'required|trim');
        
        
        if ($this->form_validation->run() == false) {

            $data['title'] = 'Page Login';
            $data['img'] = $this->captchaHelper();
            $this->load->view('template/auth_header', $data);
            $this->load->view('auth/login', $data);
            $this->load->view('template/auth_footer');
        } else {
                 
               $this->verify();
            }
            
       
    }

    private function _login()
    {   
       
        $email = $this->input->post('email');
        $password = $this->input->post('password');
    
        $user = $this->db->get_where('daftaruser', ['email' => $email])->row_array();
        // jika ada 
        if ($user) {
            //jika aktip
            if ($user['is_active'] == 1) {
               
               //is  active dan kita cek password 
                if (password_verify($password, $user['password'])) {
                    // login berhasil
                    $data = [
                        'email' => $user['email'],
                        'rule_id' => $user['rule_id']
                    ];
                    $this->session->set_userdata($data);
                    if ($user['rule_id'] == 1) {
                        $this->captcha();
                        redirect('admin');
                    } else {
                        redirect('user');
                    }
                } else {
                    //password salah
                    $this->session->set_flashdata(
                        'asd',
                        '<div class="alert alert-danger" role="alert"> wrong password ! </div>'
                    );
                    redirect('auth');
                }

            } else {    // not Active
                $this->session->set_flashdata(
                    'asd',
                    '<div class="alert alert-danger" role="alert"> Email not active! please activated </div>'
                );
                redirect('auth');
            }
        } else {
            // jika $user Kosong
            $this->session->set_flashdata(
                'asd',
                '<div class="alert alert-danger" role="alert"> Email not Registered! </div>'
            );
            redirect('auth');
        }
    }
 


    public function register()
    {
        $this->form_validation->set_rules('name', 'Name', 'required|trim');
        $this->form_validation->set_rules('email', 'Email', 'required|trim|valid_email|is_unique[daftaruser.email]', [
            'is_unique'     => 'This %s already exists.'
        ]);
        $this->form_validation->set_rules('password1', 'Password', 'trim|required|min_length[6]|matches[password2]', [
            'matches'      => 'password dont match!.',
            'required'     => 'You have not provided %s.',
            'min_length'    => 'password too short !'

        ]);
        $this->form_validation->set_rules('password2', 'Password', 'matches[password1]|required|trim');


        if ($this->form_validation->run() == false) {
            $data['title'] = 'Page Register';
            $this->load->view('template/auth_header', $data);
            $this->load->view('auth/register');
            $this->load->view('template/auth_footer');
        } else {

            $data = [
                'id'  => NULL,
                'name' => htmlspecialchars($this->input->post('name', true)),
                'email' => htmlspecialchars($this->input->post('email', true)),
                'image' => 'default.jpg',
                'password' => password_hash($this->input->post('password1'), PASSWORD_DEFAULT),
                'rule_id' => 2,
                'is_active' => 1,
                'date_created' => time()

            ];

            $this->db->insert('daftaruser', $data);
            $this->session->set_flashdata('asd', '<div class="alert alert-succes" role="alert"> your acount has bin created, Please login now </div>');
            redirect('auth');
        }
    }

    public function logout()
    {

        $this->session->unset_userdata('email');
        $this->session->unset_userdata('rule_id');

        $this->session->set_flashdata('asd', '<div class="alert alert-success" role="alert">you have been logout ! </div>');
        redirect('auth');
    }

    public function captcha(){

        

       
    }


    public function captchaHelper(){
            $vals = array(
                    // 'word'          => 'Random word',
                    'img_path'      => './asset/captcha/',
                    'img_url'       => base_url().'asset/captcha/',
                    // 'font_path'     => './path/to/fonts/texb.ttf',
                    'img_width'     => '125',
                    'img_height'    => 60,
                    'expiration'    => 7200,
                    'word_length'   => 8,
                    'font_size'     => 16,
                    'img_id'        => 'Imageid',
                    // 'pool'          => '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ',
                    'pool'          => '0123456789'

                    // White background and border, black text and red grid
            //         'colors'        => array(
            //                 'background' => array(255, 255, 255),
            //                 'border' => array(255, 255, 255),
            //                 'text' => array(0, 0, 0),
            //                 'grid' => array(255, 40, 40)
            //         )
             );
            
            $cap = create_captcha($vals);
            $this->session->set_userdata('key', $cap['word']);
            return $cap['image'];
                    
    }


    public function verify(){
        if ($this->input->post('captcha') == $this->session->userdata('key')){

             $this->session->set_flashdata('asd', '<div class="alert-success text-center btn" role="alert"> captcha valid </div>
              ');
           return $this->_login();
        }else {
            
             $this->session->set_flashdata('asd', '<div class="alert alert-danger text-center" role="alert"> invalid captcha! </div>');
          return  redirect('auth');
        }
    }




    
}
