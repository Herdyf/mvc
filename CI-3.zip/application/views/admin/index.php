

                <!-- Begin Page Content -->
                
                <div class="container-fluid">
                  <div class="col-sm-3" width="200px">
                <?= $this->session->flashdata('asd');?>
                
                </div>
                    <h3 class="display-4 text-center"> Administrator</h3>
                    <hr>
                


                </div>
                </div>

                <!-- End of Main Content -->