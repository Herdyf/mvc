<div class="container">

    <!-- Outer Row -->
    <div class="row justify-content-center">

        <div class="col-lg-7">

            <div class="card o-hidden border-0 shadow-lg my-5">
                <div class="card-body p-0">
                    <!-- Nested Row within Card Body -->
                    <div class="row ">

                        <div class="col-lg">
                            <div class="p-5">
                                <div class="text-center">
                                    <i class="fas fa-door-open">wellcome</i>
                                    <hr class="display-4">

                                </div>
                                <?= $this->session->flashdata('asd'); ?>
                                <form class="user" action="<?= base_url('auth'); ?>" method="POST">
                                    <div class="form-group ">
                                        <input type="text" class="form-control form-control-user text-center" id="email" name="email" value="<?= set_value('email'); ?>" placeholder="Enter Email">
                                        <?= form_error('email', '<small class="text-danger pl-2 ">', '</small>'); ?>
                                    </div>
                                    <div class="form-group ">
                                        <input type="password" class="form-control form-control-user text-center" id="password" name="password" placeholder="Enter password">
                                        <?= form_error('password', '<small class="text-danger pl-2 ">', '</small>'); ?>
                                        </div>
                                    <div class="form-group">
                                    <div class="  " style="">
                                    <p class=" "><?= $img;?></p>
                                    <input type="text" id="captcha" name="captcha" value="<?= $this->session->userdata('key'); ?>" class=" text-center   btn " style="max-width: 130px; border-radius:5px;">
                                    </div>
                                    </div>                              
                                       

                                    <button  type="submit" class=" mx-auto my-auto btn btn-primary btn-user btn-block " name="submit" >
                                        Login
                                    </button>

                                </form>
                                <hr>
                                <div class="text-center">
                                    <a class="small" href="#">Forgot Password?</a>
                                </div>
                                <div class="text-center">
                                    <a class="small" href="<?= base_url('auth/register'); ?>">Create an Accounst!</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>

    </div>

</div>