<!DOCTYPE html>
<html>
<head>
	<title>CodeIgniter reCAPTCHA</title>
	<!-- reCAPTCHA JavaScript API -->
	<script src='https://www.google.com/recaptcha/api.js'></script>
</head>

<body>
	<form action="form" method="POST">
		<?=$recaptcha;?>
		<button type="submit" name="action" value="submit">Submit</button>
	</form>
</body>

</html>