                <!-- Begin Page Content -->
                <div class="container-fluid">
                    <h3 class="display-3"> Profile</h3>

                    <div class="card mb-3 " style="max-width: 540px;">
                        <div class="row no-gutters">
                            <div class="pl-3 col-md-4 mx-auto my-auto">
                                <img src="<?= base_url('/asset/img/') . $user['image']; ?>" class="card-img " alt="...">
                            </div>
                            <div class="col ">
                                <div class="card-body">
                                    <h5 class="card-title text-center"><?= $user['name'] ?></h5>
                                    <p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
                                    <p class="card-text"><small class="text-muted"> Member <?= date('d F Y', $user['date_created']); ?></small></p>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
                </div>

                <!-- End of Main Content -->